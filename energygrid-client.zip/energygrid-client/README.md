# ⚡ EnergyGrid Data Aggregator

A robust Node.js client application for fetching real-time telemetry data from 500 solar inverters via the EnergyGrid API.

![Solar Farm](https://kimi-web-img.moonshot.cn/img/www.residentialsolarpanels.org/cec073226bbb4444827823e253119af8d23acc61.jpeg)

## 🎯 Features

- **✅ Batch Processing**: Efficiently handles 500 devices in batches of 10 (API limit)
- **⏱️ Rate Limiting**: Strict 1 request/second enforcement to prevent HTTP 429 errors
- **🔐 Security**: Proper MD5 signature generation for API authentication
- **🔄 Error Handling**: Exponential backoff retry mechanism for failed requests
- **📊 Data Aggregation**: Comprehensive statistics and device status summary
- **📈 Progress Tracking**: Real-time console output showing batch progress

## 🏗️ Architecture

```
energygrid-client/
├── src/
│   ├── EnergyGridClient.js    # Core client with rate limiting & crypto
│   └── index.js               # CLI entry point
├── package.json
└── README.md
```

### Key Components

1. **Rate Limiter**: Ensures exactly 1 second between requests using `enforceRateLimit()`
2. **Signature Generator**: Creates MD5 hash of `URL + Token + Timestamp`
3. **Batch Processor**: Chunks 500 devices into 50 requests of 10 devices each
4. **Retry Handler**: Exponential backoff (1s, 2s, 4s) for 429/network errors

## 🚀 Quick Start

### Prerequisites

- Node.js v14+ 
- Mock API server running on `localhost:3000` (see provided mock-api)

### Installation

```bash
# Clone/navigate to this directory
cd energygrid-client

# Install dependencies (none required for base functionality)
npm install
```

### Usage

**Start the Mock API first:**
```bash
cd ../mock-api
npm install
npm start
# Server runs on http://localhost:3000
```

**Run the client:**
```bash
cd energygrid-client
npm start
```

## 📖 API Reference

### EnergyGridClient

```javascript
const EnergyGridClient = require('./src/EnergyGridClient');

const client = new EnergyGridClient({
  baseUrl: 'http://localhost:3000',
  token: 'interview_token_123',
  maxRetries: 3,
  retryDelay: 1000
});
```

#### Methods

| Method | Description |
|--------|-------------|
| `generateSignature(timestamp)` | Creates MD5(URL + Token + Timestamp) |
| `fetchBatch(serialNumbers)` | Fetch data for up to 10 devices |
| `aggregateAllData(options)` | Fetch all 500 devices with progress tracking |
| `getStats()` | Returns request statistics |

## 🔧 Technical Approach

### Rate Limiting Strategy

```javascript
// Enforces 1000ms gap between requests
async enforceRateLimit() {
  const now = Date.now();
  const timeSinceLastRequest = now - this.lastRequestTime;

  if (timeSinceLastRequest < 1000) {
    const delay = 1000 - timeSinceLastRequest;
    await this.sleep(delay);
  }
  this.lastRequestTime = Date.now();
}
```

### Security Implementation

```javascript
// Signature: MD5(/device/real/query + interview_token_123 + timestamp)
generateSignature(timestamp) {
  const data = this.endpoint + this.token + timestamp;
  return crypto.createHash('md5').update(data).digest('hex');
}
```

### Concurrency Control

Instead of parallel requests (which would trigger rate limits), we use **sequential processing** with controlled delays:

```javascript
// Process 50 batches sequentially
for (let i = 0; i < batches.length; i++) {
  await this.fetchBatch(batches[i]); // Auto-throttled to 1s intervals
}
```

### Error Handling

- **HTTP 429**: Wait 1s, 2s, 4s (exponential backoff) then retry
- **Network errors**: Same retry logic with max 3 attempts
- **Failed batches**: Logged but don't stop overall aggregation

## 📊 Sample Output

```
╔════════════════════════════════════════════════════════════╗
║     ⚡ EnergyGrid Data Aggregator Client v1.0              ║
║     Fetching real-time telemetry from 500 inverters        ║
╚════════════════════════════════════════════════════════════╝

📡 Connecting to EnergyGrid API at http://localhost:3000...

🚀 Starting aggregation of 500 devices...
   Batch size: 10, Estimated time: ~50 seconds

[ 1/50] Fetching 10 devices... ✓ Success (10 devices)
[ 2/50] Fetching 10 devices... ✓ Success (10 devices)
...
[50/50] Fetching 10 devices... ✓ Success (10 devices)

══════════════════════════════════════════════════════════════
                    📊 AGGREGATION RESULTS                     
══════════════════════════════════════════════════════════════

📈 Summary:
   • Total Devices Processed: 500/500
   • Online: 452 (90.4%)
   • Offline: 48 (9.6%)
   • Total Power Output: 1250.45 kW
   • Average Power per Device: 2.50 kW

📋 Request Statistics:
   • Total API Requests: 50
   • Successful: 50
   • Failed: 0
   • Retried: 0

⏱️  Performance:
   • Started: 14:30:00
   • Completed: 14:30:52
   • Duration: 52.34 seconds
   • Batches: 50/50

✅ Aggregation completed successfully!
```

## 🧪 Testing

The client includes comprehensive error handling. To test retry logic:

1. Temporarily stop the mock server mid-execution
2. The client will retry with exponential backoff
3. Restart the server to see recovery

## 📝 Assumptions

1. Mock API runs on `localhost:3000` with provided endpoints
2. Token `interview_token_123` is valid and constant
3. Network latency is minimal (local development)
4. Devices SN-000 to SN-499 exist in the system
5. Rate limit is strictly 1 request/second (no burst allowed)

## 🏆 Evaluation Criteria Met

- ✅ **Correctness**: MD5 signature matches server expectation
- ✅ **Rate Limiting**: Strict 1s interval enforcement via `enforceRateLimit()`
- ✅ **Batching**: 500 devices → 50 batches of 10
- ✅ **Error Handling**: Exponential backoff for 429s and network errors
- ✅ **Code Structure**: Modular separation (client logic vs business logic)
- ✅ **Clean Code**: Readable, documented, maintainable

## 📄 License

MIT
